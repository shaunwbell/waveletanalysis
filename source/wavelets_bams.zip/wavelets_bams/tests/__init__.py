# If you import * with nosetests, all the tests will be run twice
# with py.tests, tests are only run once
# from test_wavelets import *
